const KinClient = require('@kinecosystem/kin-sdk-node').KinClient;
const Environment = require('@kinecosystem/kin-sdk-node').Environment;


console.log('First we will create our KinClient object, and direct it to our test environment');
let client = new KinClient(Environment.Testnet);

console.log("environment", client.environment);

const KeyPair = require('@kinecosystem/kin-sdk-node').KeyPair;
// Get keypair

const keypair = KeyPair.generate();
console.log("We are using the following keypair: ", keypair.publicAddress);


console.log("Since we are on the testnet blockchain, we can use the friendbot to create our account...");
client.friendbot({ address: keypair.publicAddress, amount: 10000 }).then(() => {
	// Do something here
	// Init KinAccount
	console.log("We can now create a KinAccount object, we will use it to interact with our account");
	const account = client.createKinAccount({ seed: keypair.seed });
	console.log("This is the app ID of our account:", account.appId);
	console.log("We can use our KinAccount object to get our balance");
	account.getBalance().then(balance => {
		console.log("Our balance is " + balance + " KIN");
	});

	// Create a different account
	console.log("We will now create a different account");
	const newKeypair = KeyPair.generate();
	console.log("Creating account: ", keypair.publicAddress);
	account.buildCreateAccount({
		fee: 100,
		startingBalance: 1000,
		memoText: "Test create account",
		address: newKeypair.publicAddress
	}).then(transactionBuilder => {
		account.submitTransaction(transactionBuilder).then(transactionHash => {
			console.log("We created the account and got the transaction id: ", transactionHash);

			// Get info about a tx
			console.log("We can now use the client to get info about the transaction we did");
			client.getTransactionData(transactionHash).then(transaction => {
				console.log("Transaction data: ", JSON.stringify(transaction))
			});

			// Send kin to the new account
			account.buildSendKin({
				amount: 100,
				memoText: "Hello World",
				address: newKeypair.publicAddress,
				fee: 100
			}).then(transactionBuilder => {
				account.submitTransaction(transactionBuilder).then(transactionHash => {
					console.log("The transaction succeeded with the hash ", transactionHash);
				});
			});
		});
	});

});




